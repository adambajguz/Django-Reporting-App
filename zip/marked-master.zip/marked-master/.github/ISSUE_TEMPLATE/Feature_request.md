---
name: Feature request
about: Marked doesn't do this thing and I think it should

---

**Describe the feature**
A clear and concise description of what you would like.

**Why is this feature necessary?**
A clear and concise description of why.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.
