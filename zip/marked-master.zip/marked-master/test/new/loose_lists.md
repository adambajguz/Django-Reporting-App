* hello
  world

  how
  are
* you



better behavior:

* hello
  * world
    how

    are
    you

  * today
* hi



* hello

* world
* hi



* hello
* world

* hi



* hello
* world

  how
* hi



* hello
* world
* how

  are



* hello
* world

* how

  are
