---
sanitize: true
---
lower[click me](javascript&#x3a;...)lower
upper[click me](javascript&#X3a;...)upper
