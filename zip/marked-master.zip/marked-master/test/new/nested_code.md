````` hi ther `` ok ``` `````

`` ` ``

``There is a literal backtick (`) here.``

A backtick-delimited string in a code span: `` `foo` ``

Please don't use any `<blink>` tags.